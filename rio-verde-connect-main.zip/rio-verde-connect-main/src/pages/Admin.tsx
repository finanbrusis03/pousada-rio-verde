import { useEffect, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Bed, 
  Calendar, 
  CreditCard, 
  MessageSquare, 
  Settings, 
  Users, 
  LogOut,
  Home,
  BarChart3,
  Bell,
  Plus,
  Edit,
  Trash2,
  Eye,
  DollarSign,
  TrendingUp,
  Clock
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const Admin = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    const auth = localStorage.getItem("adminAuth");
    if (!auth) {
      navigate("/admin/login");
    } else {
      setIsAuthenticated(true);
    }
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem("adminAuth");
    toast({
      title: "Logout realizado",
      description: "Você foi desconectado do painel administrativo.",
    });
    navigate("/admin/login");
  };

  if (!isAuthenticated) {
    return null;
  }

  // Dados mockados para demonstração
  const stats = [
    { label: "Reservas Hoje", value: "12", icon: Calendar, color: "text-blue-500" },
    { label: "Check-ins Pendentes", value: "4", icon: Clock, color: "text-orange-500" },
    { label: "Faturamento Mensal", value: "R$ 45.800", icon: DollarSign, color: "text-green-500" },
    { label: "Taxa de Ocupação", value: "78%", icon: TrendingUp, color: "text-purple-500" },
  ];

  const rooms = [
    { id: 1, name: "Suíte Master", capacity: 4, price: 450, status: "Disponível" },
    { id: 2, name: "Suíte Standard", capacity: 2, price: 280, status: "Ocupado" },
    { id: 3, name: "Chalé Família", capacity: 6, price: 650, status: "Disponível" },
    { id: 4, name: "Quarto Duplo", capacity: 2, price: 220, status: "Manutenção" },
  ];

  const recentReservations = [
    { id: 1, guest: "Maria Silva", room: "Suíte Master", checkin: "10/01/2026", status: "Confirmada" },
    { id: 2, guest: "João Santos", room: "Chalé Família", checkin: "12/01/2026", status: "Pendente" },
    { id: 3, guest: "Ana Costa", room: "Suíte Standard", checkin: "15/01/2026", status: "Paga" },
  ];

  return (
    <div className="min-h-screen bg-muted/30">
      {/* Header */}
      <header className="bg-background border-b sticky top-0 z-50">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-4">
              <Link to="/" className="font-display text-xl font-bold text-primary">
                Rio Verde
              </Link>
              <span className="text-sm text-muted-foreground">Painel Administrativo</span>
            </div>
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="w-5 h-5" />
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-destructive text-destructive-foreground text-xs rounded-full flex items-center justify-center">
                  3
                </span>
              </Button>
              <Button variant="ghost" size="sm" asChild>
                <Link to="/" className="flex items-center gap-2">
                  <Home className="w-4 h-4" />
                  Ver Site
                </Link>
              </Button>
              <Button variant="outline" size="sm" onClick={handleLogout} className="flex items-center gap-2">
                <LogOut className="w-4 h-4" />
                Sair
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {stats.map((stat, index) => (
              <Card key={index}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">{stat.label}</p>
                      <p className="text-2xl font-bold mt-1">{stat.value}</p>
                    </div>
                    <div className={`w-12 h-12 rounded-xl bg-muted flex items-center justify-center ${stat.color}`}>
                      <stat.icon className="w-6 h-6" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Main Tabs */}
          <Tabs defaultValue="dashboard" className="space-y-6">
            <TabsList className="bg-background border w-full justify-start overflow-x-auto">
              <TabsTrigger value="dashboard" className="flex items-center gap-2">
                <BarChart3 className="w-4 h-4" />
                Dashboard
              </TabsTrigger>
              <TabsTrigger value="rooms" className="flex items-center gap-2">
                <Bed className="w-4 h-4" />
                Quartos
              </TabsTrigger>
              <TabsTrigger value="reservations" className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                Reservas
              </TabsTrigger>
              <TabsTrigger value="payments" className="flex items-center gap-2">
                <CreditCard className="w-4 h-4" />
                Pagamentos
              </TabsTrigger>
              <TabsTrigger value="chatbot" className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4" />
                Chatbot
              </TabsTrigger>
              <TabsTrigger value="users" className="flex items-center gap-2">
                <Users className="w-4 h-4" />
                Usuários
              </TabsTrigger>
              <TabsTrigger value="settings" className="flex items-center gap-2">
                <Settings className="w-4 h-4" />
                Configurações
              </TabsTrigger>
            </TabsList>

            {/* Dashboard Tab */}
            <TabsContent value="dashboard">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Reservas Recentes</CardTitle>
                    <CardDescription>Últimas reservas recebidas</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {recentReservations.map((reservation) => (
                        <div key={reservation.id} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                          <div>
                            <p className="font-medium">{reservation.guest}</p>
                            <p className="text-sm text-muted-foreground">{reservation.room} • {reservation.checkin}</p>
                          </div>
                          <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                            reservation.status === "Confirmada" ? "bg-blue-100 text-blue-700" :
                            reservation.status === "Paga" ? "bg-green-100 text-green-700" :
                            "bg-orange-100 text-orange-700"
                          }`}>
                            {reservation.status}
                          </span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Ações Rápidas</CardTitle>
                    <CardDescription>Acesse as principais funcionalidades</CardDescription>
                  </CardHeader>
                  <CardContent className="grid grid-cols-2 gap-4">
                    <Button variant="outline" className="h-auto py-4 flex flex-col items-center gap-2">
                      <Plus className="w-5 h-5" />
                      <span>Nova Reserva</span>
                    </Button>
                    <Button variant="outline" className="h-auto py-4 flex flex-col items-center gap-2">
                      <Bed className="w-5 h-5" />
                      <span>Adicionar Quarto</span>
                    </Button>
                    <Button variant="outline" className="h-auto py-4 flex flex-col items-center gap-2">
                      <Calendar className="w-5 h-5" />
                      <span>Bloquear Datas</span>
                    </Button>
                    <Button variant="outline" className="h-auto py-4 flex flex-col items-center gap-2">
                      <MessageSquare className="w-5 h-5" />
                      <span>Ver Mensagens</span>
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Rooms Tab */}
            <TabsContent value="rooms">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <div>
                    <CardTitle>Gestão de Quartos</CardTitle>
                    <CardDescription>Gerencie os quartos e acomodações</CardDescription>
                  </div>
                  <Button className="flex items-center gap-2">
                    <Plus className="w-4 h-4" />
                    Adicionar Quarto
                  </Button>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left py-3 px-4 font-medium">Nome</th>
                          <th className="text-left py-3 px-4 font-medium">Capacidade</th>
                          <th className="text-left py-3 px-4 font-medium">Preço/Diária</th>
                          <th className="text-left py-3 px-4 font-medium">Status</th>
                          <th className="text-right py-3 px-4 font-medium">Ações</th>
                        </tr>
                      </thead>
                      <tbody>
                        {rooms.map((room) => (
                          <tr key={room.id} className="border-b last:border-0">
                            <td className="py-3 px-4 font-medium">{room.name}</td>
                            <td className="py-3 px-4">{room.capacity} pessoas</td>
                            <td className="py-3 px-4">R$ {room.price}</td>
                            <td className="py-3 px-4">
                              <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                                room.status === "Disponível" ? "bg-green-100 text-green-700" :
                                room.status === "Ocupado" ? "bg-blue-100 text-blue-700" :
                                "bg-orange-100 text-orange-700"
                              }`}>
                                {room.status}
                              </span>
                            </td>
                            <td className="py-3 px-4">
                              <div className="flex items-center justify-end gap-2">
                                <Button variant="ghost" size="icon">
                                  <Eye className="w-4 h-4" />
                                </Button>
                                <Button variant="ghost" size="icon">
                                  <Edit className="w-4 h-4" />
                                </Button>
                                <Button variant="ghost" size="icon" className="text-destructive">
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Reservations Tab */}
            <TabsContent value="reservations">
              <Card>
                <CardHeader>
                  <CardTitle>Gestão de Reservas</CardTitle>
                  <CardDescription>Visualize e gerencie todas as reservas</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-12 text-muted-foreground">
                    <Calendar className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>Conecte ao Lovable Cloud para habilitar o sistema de reservas</p>
                    <Button className="mt-4">Configurar Backend</Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Payments Tab */}
            <TabsContent value="payments">
              <Card>
                <CardHeader>
                  <CardTitle>Gestão de Pagamentos</CardTitle>
                  <CardDescription>Configure métodos de pagamento e visualize transações</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-12 text-muted-foreground">
                    <CreditCard className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>Integre o Stripe para processar pagamentos</p>
                    <Button className="mt-4">Configurar Stripe</Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Chatbot Tab */}
            <TabsContent value="chatbot">
              <Card>
                <CardHeader>
                  <CardTitle>Configuração do Chatbot</CardTitle>
                  <CardDescription>Configure o atendimento automático via WhatsApp</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-12 text-muted-foreground">
                    <MessageSquare className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>Configure a integração com WhatsApp Business API</p>
                    <Button className="mt-4">Configurar WhatsApp</Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Users Tab */}
            <TabsContent value="users">
              <Card>
                <CardHeader>
                  <CardTitle>Gestão de Usuários</CardTitle>
                  <CardDescription>Gerencie clientes e administradores</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-12 text-muted-foreground">
                    <Users className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>Conecte ao Lovable Cloud para gerenciar usuários</p>
                    <Button className="mt-4">Configurar Autenticação</Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Settings Tab */}
            <TabsContent value="settings">
              <Card>
                <CardHeader>
                  <CardTitle>Configurações Gerais</CardTitle>
                  <CardDescription>Configure informações da pousada</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Nome da Pousada</label>
                      <input 
                        type="text" 
                        defaultValue="Iate Clube Rio Verde"
                        className="w-full px-3 py-2 border rounded-lg bg-background"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">WhatsApp</label>
                      <input 
                        type="text" 
                        defaultValue="(13) 99999-9999"
                        className="w-full px-3 py-2 border rounded-lg bg-background"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Horário Check-in</label>
                      <input 
                        type="time" 
                        defaultValue="14:00"
                        className="w-full px-3 py-2 border rounded-lg bg-background"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Horário Check-out</label>
                      <input 
                        type="time" 
                        defaultValue="12:00"
                        className="w-full px-3 py-2 border rounded-lg bg-background"
                      />
                    </div>
                  </div>
                  <Button>Salvar Configurações</Button>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    </div>
  );
};

export default Admin;
