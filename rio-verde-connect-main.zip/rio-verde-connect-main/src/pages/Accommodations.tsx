import { motion } from "framer-motion";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Users, Bed, Wifi, Wind, Coffee, Tv, Bath, Mountain, ArrowRight, Check } from "lucide-react";
import roomSuite from "@/assets/room-suite.jpg";
import poolArea from "@/assets/pool-area.jpg";
import restaurantBar from "@/assets/restaurant-bar.jpg";

const accommodations = [
  {
    id: 1,
    name: "Suíte Vista Mar",
    description: "Nossa acomodação mais exclusiva, com varanda privativa e vista panorâmica para o oceano. Ideal para casais em busca de romance e tranquilidade.",
    image: roomSuite,
    capacity: { adults: 2, children: 1 },
    beds: "1 cama king size",
    size: "35m²",
    priceFrom: 350,
    amenities: [
      { icon: Wifi, label: "Wi-Fi grátis" },
      { icon: Wind, label: "Ar-condicionado" },
      { icon: Coffee, label: "Café da manhã" },
      { icon: Tv, label: "TV Smart" },
      { icon: Bath, label: "Banheira" },
      { icon: Mountain, label: "Vista mar" },
    ],
    features: [
      "Varanda privativa com rede",
      "Frigobar abastecido",
      "Amenities premium",
      "Roupão e chinelos",
      "Serviço de quarto",
    ],
  },
  {
    id: 2,
    name: "Chalé Jardim Tropical",
    description: "Chalé independente cercado por exuberante vegetação tropical. Perfeito para famílias ou grupos de amigos que buscam privacidade.",
    image: poolArea,
    capacity: { adults: 4, children: 2 },
    beds: "2 camas queen size",
    size: "55m²",
    priceFrom: 550,
    amenities: [
      { icon: Wifi, label: "Wi-Fi grátis" },
      { icon: Wind, label: "Ar-condicionado" },
      { icon: Coffee, label: "Café da manhã" },
      { icon: Tv, label: "TV Smart" },
      { icon: Bath, label: "Banheiro privativo" },
      { icon: Mountain, label: "Vista jardim" },
    ],
    features: [
      "Área externa privativa",
      "Churrasqueira",
      "Cozinha equipada",
      "Duas suítes",
      "Estacionamento frontal",
    ],
  },
  {
    id: 3,
    name: "Quarto Standard Conforto",
    description: "Acomodação aconchegante com todo conforto essencial. Excelente custo-benefício para quem quer aproveitar a estrutura da pousada.",
    image: restaurantBar,
    capacity: { adults: 2, children: 0 },
    beds: "1 cama casal",
    size: "22m²",
    priceFrom: 250,
    amenities: [
      { icon: Wifi, label: "Wi-Fi grátis" },
      { icon: Wind, label: "Ar-condicionado" },
      { icon: Coffee, label: "Café da manhã" },
      { icon: Tv, label: "TV" },
    ],
    features: [
      "Banheiro privativo",
      "Frigobar",
      "Roupa de cama premium",
      "Acesso à piscina",
    ],
  },
];

export default function Accommodations() {
  return (
    <Layout>
      {/* Hero */}
      <section className="pt-32 pb-16 bg-muted/50">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center max-w-2xl mx-auto"
          >
            <span className="text-accent font-medium text-sm uppercase tracking-wider">
              Acomodações
            </span>
            <h1 className="font-display text-4xl md:text-5xl font-bold mt-3 mb-4">
              Escolha Seu Refúgio
            </h1>
            <p className="text-muted-foreground text-lg">
              Cada acomodação foi pensada para proporcionar conforto e integração 
              com a natureza exuberante do litoral sul paulista.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Accommodations List */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="space-y-16">
            {accommodations.map((room, index) => (
              <motion.article
                key={room.id}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.6 }}
                className={`grid grid-cols-1 lg:grid-cols-2 gap-8 items-center ${
                  index % 2 === 1 ? "lg:flex-row-reverse" : ""
                }`}
              >
                {/* Image */}
                <div className={`${index % 2 === 1 ? "lg:order-2" : ""}`}>
                  <div className="relative rounded-2xl overflow-hidden shadow-elevated aspect-[4/3]">
                    <img
                      src={room.image}
                      alt={room.name}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-4 left-4 bg-accent text-accent-foreground px-4 py-2 rounded-full font-semibold">
                      A partir de R$ {room.priceFrom}/noite
                    </div>
                  </div>
                </div>

                {/* Content */}
                <div className={`space-y-6 ${index % 2 === 1 ? "lg:order-1" : ""}`}>
                  <div>
                    <h2 className="font-display text-3xl font-bold mb-3">
                      {room.name}
                    </h2>
                    <p className="text-muted-foreground text-lg">
                      {room.description}
                    </p>
                  </div>

                  {/* Quick Info */}
                  <div className="flex flex-wrap gap-4 py-2">
                    <div className="flex items-center gap-2 text-sm">
                      <Users className="w-5 h-5 text-primary" />
                      <span>{room.capacity.adults} adultos {room.capacity.children > 0 && `+ ${room.capacity.children} criança(s)`}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Bed className="w-5 h-5 text-primary" />
                      <span>{room.beds}</span>
                    </div>
                    <div className="px-3 py-1 bg-muted rounded-full text-sm">
                      {room.size}
                    </div>
                  </div>

                  {/* Amenities */}
                  <div className="flex flex-wrap gap-3">
                    {room.amenities.map((amenity) => (
                      <div
                        key={amenity.label}
                        className="flex items-center gap-2 px-3 py-2 bg-muted rounded-lg text-sm"
                      >
                        <amenity.icon className="w-4 h-4 text-primary" />
                        {amenity.label}
                      </div>
                    ))}
                  </div>

                  {/* Features */}
                  <div className="grid grid-cols-2 gap-2">
                    {room.features.map((feature) => (
                      <div key={feature} className="flex items-center gap-2 text-sm">
                        <Check className="w-4 h-4 text-accent" />
                        {feature}
                      </div>
                    ))}
                  </div>

                  {/* CTA */}
                  <div className="flex gap-4 pt-4">
                    <Button variant="default" size="lg" asChild>
                      <Link to="/reservar" className="flex items-center gap-2">
                        Reservar
                        <ArrowRight className="w-4 h-4" />
                      </Link>
                    </Button>
                    <Button variant="outline" size="lg" asChild>
                      <a
                        href="https://wa.me/5513999999999"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        Tirar Dúvidas
                      </a>
                    </Button>
                  </div>
                </div>
              </motion.article>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h2 className="font-display text-3xl font-bold mb-4">
            Não encontrou o que procura?
          </h2>
          <p className="text-primary-foreground/80 mb-8 max-w-lg mx-auto">
            Entre em contato conosco. Temos opções especiais para grupos, 
            eventos e estadias prolongadas.
          </p>
          <Button variant="heroOutline" size="xl" asChild>
            <Link to="/contato">Fale Conosco</Link>
          </Button>
        </div>
      </section>
    </Layout>
  );
}
