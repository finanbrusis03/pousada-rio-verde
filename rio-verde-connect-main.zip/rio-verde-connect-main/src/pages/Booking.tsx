import { motion } from "framer-motion";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Calendar, Users, Bed, ArrowLeft, MessageCircle, Check } from "lucide-react";
import { Link } from "react-router-dom";
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

const rooms = [
  { id: 1, name: "Suíte Vista Mar", price: 350, capacity: 3 },
  { id: 2, name: "Chalé Jardim Tropical", price: 550, capacity: 6 },
  { id: 3, name: "Quarto Standard Conforto", price: 250, capacity: 2 },
];

export default function Booking() {
  const [step, setStep] = useState(1);
  const [selectedRoom, setSelectedRoom] = useState<typeof rooms[0] | null>(null);

  const handleRoomSelect = (room: typeof rooms[0]) => {
    setSelectedRoom(room);
    setStep(2);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("Reserva enviada! Você receberá a confirmação por e-mail e WhatsApp.");
    setStep(3);
  };

  return (
    <Layout>
      {/* Hero */}
      <section className="pt-32 pb-8 bg-muted/50">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl mx-auto"
          >
            <Link
              to="/"
              className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-6"
            >
              <ArrowLeft className="w-4 h-4" />
              Voltar ao início
            </Link>

            <div className="text-center">
              <span className="text-accent font-medium text-sm uppercase tracking-wider">
                Reservas
              </span>
              <h1 className="font-display text-4xl md:text-5xl font-bold mt-3 mb-4">
                Faça Sua Reserva
              </h1>
              <p className="text-muted-foreground text-lg">
                Reserve diretamente conosco e garanta as melhores condições.
              </p>
            </div>

            {/* Progress */}
            <div className="flex items-center justify-center gap-4 mt-8">
              {[1, 2, 3].map((s) => (
                <div key={s} className="flex items-center gap-2">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                      step >= s
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted text-muted-foreground"
                    }`}
                  >
                    {step > s ? <Check className="w-4 h-4" /> : s}
                  </div>
                  <span className={`text-sm hidden sm:block ${step >= s ? "text-foreground" : "text-muted-foreground"}`}>
                    {s === 1 && "Acomodação"}
                    {s === 2 && "Dados"}
                    {s === 3 && "Confirmação"}
                  </span>
                  {s < 3 && <div className="w-8 h-0.5 bg-muted" />}
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Booking Content */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            {/* Step 1: Select Room */}
            {step === 1 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <h2 className="font-display text-2xl font-bold">
                  Escolha sua acomodação
                </h2>

                <div className="space-y-4">
                  {rooms.map((room) => (
                    <button
                      key={room.id}
                      onClick={() => handleRoomSelect(room)}
                      className="w-full text-left bg-card rounded-xl p-6 border border-border hover:border-primary hover:shadow-card transition-all"
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-semibold text-lg mb-2">{room.name}</h3>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Users className="w-4 h-4" />
                              Até {room.capacity} pessoas
                            </span>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-2xl font-bold text-primary">
                            R$ {room.price}
                          </p>
                          <p className="text-sm text-muted-foreground">/noite</p>
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </motion.div>
            )}

            {/* Step 2: Guest Details */}
            {step === 2 && selectedRoom && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <div className="flex items-center justify-between">
                  <h2 className="font-display text-2xl font-bold">
                    Dados da Reserva
                  </h2>
                  <button
                    onClick={() => setStep(1)}
                    className="text-sm text-muted-foreground hover:text-foreground"
                  >
                    Alterar acomodação
                  </button>
                </div>

                {/* Selected Room Summary */}
                <div className="bg-muted/50 rounded-xl p-4 flex items-center justify-between">
                  <div>
                    <p className="font-semibold">{selectedRoom.name}</p>
                    <p className="text-sm text-muted-foreground">
                      A partir de R$ {selectedRoom.price}/noite
                    </p>
                  </div>
                  <Bed className="w-6 h-6 text-primary" />
                </div>

                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="checkin">Data de Check-in</Label>
                      <Input
                        id="checkin"
                        type="date"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="checkout">Data de Check-out</Label>
                      <Input
                        id="checkout"
                        type="date"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="adults">Adultos</Label>
                      <Input
                        id="adults"
                        type="number"
                        min="1"
                        max={selectedRoom.capacity}
                        defaultValue="2"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="children">Crianças</Label>
                      <Input
                        id="children"
                        type="number"
                        min="0"
                        defaultValue="0"
                      />
                    </div>
                  </div>

                  <div className="border-t border-border pt-6">
                    <h3 className="font-semibold mb-4">Dados do Hóspede</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Nome completo</Label>
                        <Input
                          id="name"
                          placeholder="Seu nome"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email">E-mail</Label>
                        <Input
                          id="email"
                          type="email"
                          placeholder="seu@email.com"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="phone">WhatsApp</Label>
                        <Input
                          id="phone"
                          type="tel"
                          placeholder="(00) 00000-0000"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="document">CPF</Label>
                        <Input
                          id="document"
                          placeholder="000.000.000-00"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-4 pt-4">
                    <Button type="submit" variant="default" size="lg" className="flex-1">
                      Solicitar Reserva
                    </Button>
                  </div>
                </form>
              </motion.div>
            )}

            {/* Step 3: Confirmation */}
            {step === 3 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center py-12"
              >
                <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Check className="w-10 h-10 text-primary" />
                </div>
                <h2 className="font-display text-3xl font-bold mb-4">
                  Solicitação Enviada!
                </h2>
                <p className="text-muted-foreground mb-8 max-w-md mx-auto">
                  Recebemos sua solicitação de reserva. Nossa equipe entrará em contato 
                  em até 2 horas para confirmar a disponibilidade e enviar o link de pagamento.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button variant="default" size="lg" asChild>
                    <Link to="/">Voltar ao Início</Link>
                  </Button>
                  <Button variant="whatsapp" size="lg" asChild>
                    <a
                      href="https://wa.me/5513999999999"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2"
                    >
                      <MessageCircle className="w-4 h-4" />
                      Falar no WhatsApp
                    </a>
                  </Button>
                </div>
              </motion.div>
            )}
          </div>
        </div>
      </section>

      {/* Info Box */}
      {step < 3 && (
        <section className="pb-16 bg-background">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto bg-primary/5 border border-primary/20 rounded-2xl p-6">
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                <Calendar className="w-5 h-5 text-primary" />
                Informações Importantes
              </h3>
              <ul className="text-sm text-muted-foreground space-y-2">
                <li>• Check-in: a partir das 14:00 | Check-out: até 12:00</li>
                <li>• Pagamento: Pix ou cartão de crédito (até 6x sem juros)</li>
                <li>• Cancelamento gratuito até 7 dias antes do check-in</li>
                <li>• Dúvidas? Fale conosco pelo WhatsApp: (13) 99999-9999</li>
              </ul>
            </div>
          </div>
        </section>
      )}
    </Layout>
  );
}
